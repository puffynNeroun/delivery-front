// src/mock/products.ts
export const products = [
    {
        id: "1",
        name: "Калифорния классика",
        type: "Роллы",
        price: 350,
        image: "/inform.jpeg",
    },
    {
        id: "2",
        name: "Филадельфия люкс",
        type: "Роллы",
        price: 450,
        image: "/example.jpeg",
    },
];
